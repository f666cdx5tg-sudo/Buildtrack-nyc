# 🏗️ BuildTrack NYC

### Multi-Phase, Multi-Trade Construction Monitoring App for NYC Apartment Buildings

![License](https://img.shields.io/badge/license-MIT-green)
![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Status](https://img.shields.io/badge/status-active-brightgreen)

A comprehensive, real-time construction monitoring application designed for large-scale NYC apartment building renovations. Track work across **500+ units**, **10 trades**, and **multiple phases** — all from a single dashboard.

---

## 🎨 Preview

The app features a neon NYC skyline header, apple green & pink color scheme, and a collapsible sidebar navigation.

### Color Code System
| Color | Status |
|-------|--------|
| 🔴 **Red** `#FF4D6D` | No work has begun |
| 🟡 **Yellow-Green** `#CDEB45` | Work has started |
| 🟢 **Green** `#70E000` | Work completed |
| 🟠 **Orange/Pink** `#FFB3C6` | Unit is vacant |

---

## ✨ Features

### 🏢 Dashboard
- **Color-coded unit grid** — visual overview of all units at a glance
- **Real-time stats** — total units, active work, completed, not started, vacant, access issues
- **Search & filter** — by floor, status, unit number, or resident name
- **Scalable** — supports 25 to 500 units with floor/unit configuration

### 🔨 10 Trade Pages
Each trade has a dedicated view with status breakdown and unit map:
- Plumbing, Carpentry, Windows, Electrical, Painting
- Heating, Cooling, Tiling
- Minor Repairs, Major Repairs

### 📋 Unit Detail Modal (5 Tabs)
- **Info** — Contact: first/last name, phone, email, unit number, floor, vacancy toggle
- **Trades** — Per-trade status (Not Started / In Progress / Complete), phase selector, access denied flag
- **Comments** — Text comments with spell check + voice recording with transcription
- **Photos** — Photo annotations with marking/annotation capability
- **Notices** — Generate and send notices per unit (Print / Email / Text)

### 📅 Scheduling
- **Global Schedule** — Gantt-style progress bars for all trades
- **Per-Trade Schedule** — Individual trade timelines with start/end dates
- **2-Week Look Ahead** — Upcoming work by trade with access issue warnings

### 🔧 Common Areas
- **Elevators** — Car 1-4 with trade assignments and status
- **Roof** — Main Roof, Bulkhead, Water Tower, Antenna Platform
- **Basement** — Boiler Room, Storage, Laundry, Mechanical
- **Grounds** — Front Entrance, Courtyard, Parking, Sidewalk

### 📡 Field Monitor
- **Live event log** — real-time field activity feed
- **Access denied dashboard** — units where contractors can't gain entry
- **Daily summary** — at-a-glance stats for the day

### 📋 Bulk Notices
- Select units individually, by floor, or all at once
- Choose trades, set work dates, write notice content
- **Print** — generate printable notices for each unit
- **Email** — distribute electronically to multiple residents
- **Text** — SMS version for quick distribution
- All notices saved to Desktop/Notices/ folder

### 🏗️ Building Configuration
- **Unit format toggle** — `1A, 1B, 2A...` (alpha) or `101, 102, 201...` (numeric)
- **Floor count** — 1 to 50 floors
- **Unit count** — 25 to 500 units in increments of 1
- **Per-floor readout** — auto-calculated units per floor

### 📱 Header Info Bar
- **Line 1:** Day of week + date (MM-DD-YYYY)
- **Line 2:** Live clock (updates every second)
- **Line 3:** Project name (click to edit)
- **Line 4:** Weather conditions + temperature
- **Background:** Neon NYC skyline silhouette

---

## 🚀 Quick Start

### Option 1: Standalone HTML (Zero Setup)
```bash
# Just open the file in any browser
open index.html
```
No build tools, no dependencies, no server required.

### Option 2: React Component
```bash
# Create a new React project
npx create-react-app buildtrack
cd buildtrack

# Copy the component
cp src/construction-monitor.jsx buildtrack/src/App.jsx

# Install and run
npm start
```

### Option 3: GitHub Pages
1. Fork this repo
2. Go to Settings → Pages
3. Set source to `main` branch, `/ (root)` folder
4. Your app is live at `https://yourusername.github.io/buildtrack-nyc/`

---

## 📁 Project Structure

```
buildtrack-nyc/
├── index.html                          # Standalone HTML app (zero dependencies)
├── src/
│   └── construction-monitor.jsx        # React component version
├── docs/
│   └── neon-skyline.jpg               # NYC neon skyline background image
├── screenshots/                        # App screenshots
├── README.md
├── LICENSE
├── CONTRIBUTING.md
├── .gitignore
└── package.json
```

---

## 🛠️ Tech Stack

| Component | Technology |
|-----------|-----------|
| **HTML Version** | Vanilla JavaScript, CSS3, HTML5 |
| **React Version** | React 18+, Hooks, JSX |
| **Fonts** | JetBrains Mono, DM Sans (Google Fonts) |
| **Styling** | CSS Custom Properties, Inline Styles |
| **Data** | Client-side state (no backend required) |

---

## 🔧 Configuration

### Building Setup
The app initializes with demo data. To configure for your building:

1. **Set unit count** — use the dropdown in the header (25-500)
2. **Set floor count** — adjust floors (1-50)
3. **Choose format** — toggle between alpha (1A, 1B) and numeric (101, 102)
4. **Edit project name** — click the project name in the header

### Color Scheme (CSS Variables)
```css
:root {
  --ag: #70E000;    /* Apple Green - primary */
  --ag2: #CDEB45;   /* Light Green - in progress */
  --pk: #FF69B4;    /* Hot Pink - accents */
  --pk2: #FF4D6D;   /* Rose Pink - alerts/not started */
  --pk3: #FFB3C6;   /* Soft Pink - vacant */
  --bg1: #0A0E0A;   /* Deep background */
  --bg2: #111A11;   /* Card background */
  --bg3: #1A2A1A;   /* Elevated background */
  --bd: #2D3D2D;    /* Borders */
  --txt: #D4E8D0;   /* Primary text */
  --txt2: #8FA88A;  /* Muted text */
}
```

---

## 🗺️ Roadmap

### Phase 2 (Planned)
- [ ] Backend API integration (Node.js/Express + PostgreSQL)
- [ ] Real camera/photo upload with file storage
- [ ] Web Speech API for actual voice recording + transcription
- [ ] Email/SMS integration (SendGrid/Twilio)
- [ ] PDF notice generation
- [ ] User authentication and role-based access
- [ ] Real-time collaboration (WebSocket)

### Phase 3 (Future)
- [ ] Mobile-native app (React Native)
- [ ] Offline-first with service workers
- [ ] Integration with building management systems
- [ ] DOB inspection scheduling
- [ ] Contractor management and payments
- [ ] Document management (permits, insurance, etc.)
- [ ] Analytics and reporting dashboard
- [ ] QR code unit identification

---

## 🤝 Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

---

## 📄 License

This project is licensed under the MIT License — see the [LICENSE](LICENSE) file for details.

---

## 👷 Built For

NYC construction managers, general contractors, project managers, and building owners managing large-scale apartment renovations where tracking work across hundreds of units and multiple trades is critical.

---

**BuildTrack NYC** — *Because managing 500 apartments shouldn't require 500 spreadsheets.*
