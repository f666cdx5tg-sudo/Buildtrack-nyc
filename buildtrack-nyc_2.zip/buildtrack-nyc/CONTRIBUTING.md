# Contributing to BuildTrack NYC

## How to Contribute

1. **Fork** the repo
2. **Clone** your fork: `git clone https://github.com/yourusername/buildtrack-nyc.git`
3. **Create a branch**: `git checkout -b feature/your-feature-name`
4. **Make changes** and test thoroughly
5. **Commit**: `git commit -m "Add: description of your change"`
6. **Push**: `git push origin feature/your-feature-name`
7. **Open a Pull Request**

## Development

### HTML Version
The standalone `index.html` is a single-file app. Open it directly in a browser — no build step needed.

### React Version
The `src/construction-monitor.jsx` file is a React component. Drop it into any React 18+ project as `App.jsx`.

## Code Style

- Use ES6+ syntax
- CSS custom properties for theming (see `:root` variables)
- Keep the HTML version and React version feature-equivalent
- Test across Chrome, Firefox, Safari, and Edge

## Reporting Issues

Open an issue with:
- Browser and version
- Steps to reproduce
- Expected vs actual behavior
- Screenshots if applicable

## Feature Requests

Open an issue with the `enhancement` label describing:
- The problem it solves
- Who benefits from it
- Any implementation ideas
